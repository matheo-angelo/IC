A folder to save trained models.
